fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'Core LB Appli'
author 'Bendev'
description 'Appli LB Phone / LB Tablet'
version '1.0.4'

dependencies {
    'es_extended',
    'oxmysql'
}

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

-- Le client lit les config.lua (LoadResourceFile) et le NUI charge le html :
-- tout doit etre declare ici, en liste explicite (les globs * / ** posent probleme).
files {
    'apps/auto_exotic/config.lua',
    'apps/auto_exotic/html/index.html',
    'apps/auto_exotic/html/logo.png',
    'apps/bahama_app/config.lua',
    'apps/bahama_app/html/index.html',
    'apps/bahama_app/html/logo.png',
    'apps/bennys_app/config.lua',
    'apps/bennys_app/html/index.html',
    'apps/bennys_app/html/logo.png',
    'apps/burgershot_app/config.lua',
    'apps/burgershot_app/html/index.html',
    'apps/burgershot_app/html/logo.png',
    'apps/lspd_app/config.lua',
    'apps/lspd_app/html/index.html',
    'apps/lspd_app/html/logo.png',
    'apps/lspd_app/html/icon.png',
    'apps/bcso_app/config.lua',
    'apps/bcso_app/html/index.html',
    'apps/bcso_app/html/logo.png',
    'apps/bcso_app/html/icon.png',
    'apps/lb_meteo/config.lua',
    'apps/lb_meteo/client.lua',
    'apps/lb_meteo/html/index.html',
    'apps/lb_meteo/html/icon.png',
    'apps/pdm_app/config.lua',
    'apps/pdm_app/html/index.html',
    'apps/pdm_app/html/logo.png',
    'apps/tequilala_app/config.lua',
    'apps/tequilala_app/html/index.html',
    'apps/tequilala_app/html/logo.png',
}

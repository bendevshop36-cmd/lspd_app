local RES = GetCurrentResourceName()

local function loadFile(app, env, rel)
    local path = ('apps/%s/%s'):format(app.key, rel)
    local code = LoadResourceFile(RES, path)
    if not code or code == '' then
        return false, ('%s introuvable'):format(path)
    end
    local fn, err = load(code, '@' .. RES .. '/' .. path, 't', env)
    if not fn then return false, err end
    local ok, runErr = pcall(fn)
    if not ok then return false, runErr end
    return true
end

local function startApp(app)
    local env = setmetatable({ APP_PATH = ('apps/%s/'):format(app.key) }, { __index = _G })

    local files = { 'config.lua' }
    if app.type == 'db' then
        files[#files + 1] = 'server/sql.lua'
        files[#files + 1] = 'server/main.lua'
    end

    for _, rel in ipairs(files) do
        local ok, err = loadFile(app, env, rel)
        if not ok then
            print(('^1[core_appli] %s : échec au chargement de %s -> %s^7'):format(app.key, rel, tostring(err)))
            return false
        end
    end
    print(('^2[core_appli] %s chargée^7'):format(app.key))
    return true
end

for _, app in ipairs(Core.Apps) do
    if app.enabled then
        -- une app qui plante ne bloque pas les autres
        local ok, err = pcall(startApp, app)
        if not ok then
            print(('^1[core_appli] %s : erreur %s^7'):format(app.key, tostring(err)))
        end
    end
end

Config = {}

-- Identifiant interne de l'application (ne pas changer après installation)
Config.AppIdentifier = 'autoexotic'
Config.AppName       = 'Auto Exotic'
Config.AppDescription = 'Prestations, tarifs, avis et recrutement du garage Auto Exotic'

-- Compatibilité : mettre false pour désactiver un des deux supports
Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet

-- LB Tablet : false = chemin « html/index.html » (recommandé par la doc LB Tablet).
-- Si l'app reste blanche sur la tablette, essayer true.
Config.TabletUiWithResourceName = false

-- false = l'app n'est PAS imposée : le joueur l'installe depuis l'App Store du téléphone
-- et peut ensuite la SUPPRIMER comme n'importe quelle autre application.
-- true  = l'app est préinstallée chez tous les joueurs (et ne se désinstalle pas).
Config.DefaultApp = false

-- Symbole de monnaie affiché dans l'interface
Config.Currency = '$'

-- Accès patron (vérifié côté serveur)
Config.Job            = 'mechanic'  -- nom du job ESX d'Auto Exotic
Config.MinGrade       = 3           -- grade minimum considéré comme « patron »
Config.BossGradeName  = 'boss'      -- ou nom du grade patron dans ta table job_grades

-- Propriétaires forcés (par identifier ESX), utile pour les tests
-- Exemple : ['license:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'] = true
Config.Owners = {}

-- Anti-spam (secondes entre deux envois du même joueur)
Config.Cooldown = {
    application = 30,
    request     = 30,
    review      = 15,
    appointment = 30
}

-- Rendez-vous : nombre maximum de RDV « en attente / confirmés » par joueur
Config.MaxActiveAppointments = 3

-- Si le joueur n'a pas de téléphone équipé, afficher une notification ESX classique
Config.EsxNotifyFallback = true

-- Valeurs par défaut créées uniquement si la base est vide
Config.DefaultSettings = {
    name        = 'Auto Exotic',
    description = 'Fixing Station : réparation, entretien et dépannage de tous vos véhicules.',
    phone       = '',
    email       = '',
    hours       = 'Lundi - Vendredi : 10h - 22h\nSamedi - Dimanche : 14h - 22h'
}

Config.DefaultCategories = {
    'Réparation mécanique',
    'Réparation moteur',
    'Réparation carrosserie',
    'Réparation des pneus',
    'Entretien automobile',
    'Dépannage',
    'Remorquage',
    'Déplacement du mécanicien',
    'Autres prestations'
}

-- { catégorie, nom, description, prix, conditions }
Config.DefaultServices = {
    { 'Réparation mécanique',      'Réparation mécanique',  'Remise en état des organes mécaniques du véhicule.', 350, 'Véhicule présent au garage ou sur place.' },
    { 'Réparation moteur',         'Réparation moteur',     'Diagnostic et réparation complète du moteur.', 600, '' },
    { 'Réparation carrosserie',    'Réparation carrosserie','Remise en état de la carrosserie et des vitres.', 450, '' },
    { 'Réparation des pneus',      'Remplacement de pneus', 'Remplacement ou réparation des pneus crevés.', 150, 'Prix par pneu.' },
    { 'Entretien automobile',      'Entretien complet',     'Vidange, contrôle des freins et du moteur.', 250, '' },
    { 'Dépannage',                 'Dépannage sur place',   'Intervention rapide pour remettre votre véhicule en route.', 300, 'Selon disponibilité des mécaniciens.' },
    { 'Remorquage',                'Remorquage',            "Remorquage jusqu'au garage Auto Exotic.", 400, '' },
    { 'Déplacement du mécanicien', 'Déplacement',           'Un mécanicien se déplace à votre position.', 100, 'Hors prix de la réparation.' }
}

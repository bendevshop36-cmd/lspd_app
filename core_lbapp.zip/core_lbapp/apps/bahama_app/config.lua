Config = {}

-- Identifiant interne de l'application (ne pas changer après installation)
Config.AppIdentifier = 'bahama'
Config.AppName       = 'Bahama'
Config.AppDescription = 'Carte, réservations, avis et recrutement de Bahama West Mamas'

-- Compatibilité : mettre false pour désactiver un des deux supports
Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet

-- LB Tablet : false = chemin « html/index.html » (recommandé par la doc LB Tablet).
-- Si l'app reste blanche sur la tablette, essayer true.
Config.TabletUiWithResourceName = false

-- false = l'app n'est PAS imposée : le joueur l'installe depuis l'App Store du téléphone
-- et peut ensuite la SUPPRIMER comme n'importe quelle autre application.
-- true  = l'app est préinstallée chez tous les joueurs (et ne se désinstalle pas).
Config.DefaultApp = false

-- Lien de l'image de la carte (affichée dans l'onglet Carte, agrandissable)
Config.MenuImage = ''   -- ex. : 'https://.../carte.png'

-- Symbole de monnaie affiché dans l'interface
Config.Currency = '$'

-- Accès patron (vérifié côté serveur)
Config.Job            = 'bahama'  -- nom du job ESX de Bahama
Config.MinGrade       = 5           -- grade minimum considéré comme « patron »
Config.BossGradeName  = 'boss'      -- ou nom du grade patron dans ta table job_grades

-- Propriétaires forcés (par identifier ESX), utile pour les tests
-- Exemple : ['license:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'] = true
Config.Owners = {}

-- Anti-spam (secondes entre deux envois du même joueur)
Config.Cooldown = {
    application = 30,
    request     = 30,
    review      = 15,
    appointment = 30
}

-- Rendez-vous : nombre maximum de RDV « en attente / confirmés » par joueur
Config.MaxActiveAppointments = 3

-- Menu : nombre maximum de liens (affiches / pages) que le patron peut publier
Config.MaxMenuLinks = 12

-- Si le joueur n'a pas de téléphone équipé, afficher une notification ESX classique
Config.EsxNotifyFallback = true

-- Valeurs par défaut créées uniquement si la base est vide
Config.DefaultSettings = {
    name        = 'Bahama West Mamas',
    description = 'Bahama West Mamas : cocktails, musique et soirées inoubliables. Réservez votre table et vivez la nuit.',
    phone       = '',
    email       = '',
    hours       = 'Mercredi - Dimanche : 22h - 6h'
}

Config.DefaultCategories = {}

-- Exemples de départ, tous modifiables ensuite dans Espace patron > Carte
-- { catégorie, nom, description, prix, conditions }
Config.DefaultServices = {}

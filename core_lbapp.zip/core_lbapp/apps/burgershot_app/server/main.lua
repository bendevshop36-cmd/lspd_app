local ESX = exports['es_extended']:getSharedObject()

local Public, Admin = {}, {}
local Perms = {}      -- identifiers ayant reçu un accès délégué par le patron
local lastAction = {} -- anti-spam

-- ─────────────────────────────── Utilitaires ───────────────────────────────

local function clean(value, max)
    value = tostring(value or ''):gsub('^%s+', ''):gsub('%s+$', '')
    value = value:gsub('[\0-\8\11\12\14-\31]', '')
    if max then
        local cut = utf8.offset(value, max + 1)
        if cut then value = value:sub(1, cut - 1) end
    end
    return value
end

local function cooldown(src, key, seconds)
    local id = src .. ':' .. key
    local now = os.time()
    if lastAction[id] and now - lastAction[id] < seconds then
        return false
    end
    lastAction[id] = now
    return true
end

AddEventHandler('playerDropped', function()
    local src = tostring(source)
    for id in pairs(lastAction) do
        if id:sub(1, #src + 1) == src .. ':' then lastAction[id] = nil end
    end
end)

local function isBoss(xp)
    if not xp then return false end
    if Config.Owners[xp.identifier] then return true end
    local job = xp.getJob()
    return job and job.name == Config.Job
        and (job.grade >= Config.MinGrade or job.grade_name == Config.BossGradeName) or false
end

local function isAdmin(xp)
    return xp ~= nil and (isBoss(xp) or Perms[xp.identifier] == true)
end

local function loadPerms()
    Perms = {}
    local rows = MySQL.query.await('SELECT identifier FROM bs_permissions') or {}
    for _, r in ipairs(rows) do Perms[r.identifier] = true end
end

local function logActivity(text)
    MySQL.insert('INSERT INTO bs_activity (text) VALUES (?)', { clean(text, 250) })
end

-- ─────────────────────────────── Notifications ─────────────────────────────

local function push(src, title, content)
    local sent = false
    if Config.Phone and GetResourceState('lb-phone') == 'started' then
        pcall(function()
            local number = exports['lb-phone']:GetEquippedPhoneNumber(src)
            if number then
                exports['lb-phone']:SendNotification(number, {
                    app = Config.AppIdentifier, title = title, content = content
                })
                sent = true
            end
        end)
    end
    if not sent and Config.EsxNotifyFallback then
        local xp = ESX.GetPlayerFromId(src)
        if xp then xp.showNotification(('%s : %s'):format(title, content)) end
    end
end

-- Notification enregistrée en base (visible dans l'app même hors ligne) + push si connecté
local function notifyPlayer(identifier, title, content)
    MySQL.insert('INSERT INTO bs_notifications (identifier, title, content) VALUES (?, ?, ?)',
        { identifier, clean(title, 120), clean(content, 500) })
    local xp = ESX.GetPlayerFromIdentifier(identifier)
    if xp then push(xp.source, title, content) end
end

local function notifyAdmins(title, content)
    for _, xp in pairs(ESX.GetExtendedPlayers()) do
        if isAdmin(xp) then push(xp.source, title, content) end
    end
end

-- ─────────────────────────────── Paramètres ────────────────────────────────

local SETTING_KEYS = { name = 80, description = 500, phone = 30, email = 80, hours = 400 }

local function getSettings()
    local out = {}
    for _, r in ipairs(MySQL.query.await('SELECT k, v FROM bs_settings') or {}) do out[r.k] = r.v end
    return out
end

local DATE = "DATE_FORMAT(created_at, '%d/%m/%Y %H:%i')"

-- ═══════════════════════════ ACTIONS PUBLIQUES ═════════════════════════════

-- URL saisie par le patron : http(s) uniquement, sans espace ni caractère dangereux
local function cleanUrl(value)
    value = clean(value, 500)
    if value == '' then return nil end
    if not value:match('^https?://[^%s"\'<>\\`]+$') then return nil end
    if not value:match('^https?://[^/%?#]+%.[^/%?#]+') then return nil end
    return value
end

Public.bootstrap = function(xp)
    local admin = isAdmin(xp)
    local data = {
        name     = xp.getName(),
        isAdmin  = admin,
        isBoss   = isBoss(xp),
        currency = Config.Currency,
        menuImage = Config.MenuImage,
        settings = getSettings(),
        news     = MySQL.query.await(
            "SELECT id, kind, title, content, DATE_FORMAT(created_at, '%d/%m/%Y') AS date FROM bs_news ORDER BY id DESC LIMIT 20") or {},
        unread   = MySQL.scalar.await(
            'SELECT COUNT(*) FROM bs_notifications WHERE identifier = ? AND is_read = 0', { xp.identifier }) or 0
    }
    local rs = MySQL.single.await('SELECT COUNT(*) AS total, AVG(rating) AS avg FROM bs_reviews WHERE hidden = 0') or {}
    data.rating = { total = rs.total or 0, avg = rs.avg and tonumber(rs.avg) or 0 }
    data.serviceCount = MySQL.scalar.await('SELECT COUNT(*) FROM bs_services WHERE active = 1') or 0
    if admin then
        data.badge = {
            apps     = MySQL.scalar.await("SELECT COUNT(*) FROM bs_applications WHERE status = 'pending'") or 0,
            requests = MySQL.scalar.await("SELECT COUNT(*) FROM bs_requests WHERE status = 'new'") or 0,
            rdv      = MySQL.scalar.await("SELECT COUNT(*) FROM bs_appointments WHERE status = 'pending'") or 0
        }
    end
    return data
end

Public.menuLinks = function()
    return MySQL.query.await('SELECT id, title, url FROM bs_menu_links WHERE active = 1 ORDER BY sort_order, id') or {}
end

Public.services = function()
    return {
        categories = MySQL.query.await('SELECT id, name FROM bs_categories ORDER BY sort_order, name') or {},
        services   = MySQL.query.await([[
            SELECT s.id, s.category_id, c.name AS category, s.name, s.description, s.price, s.conditions
            FROM bs_services s JOIN bs_categories c ON c.id = s.category_id
            WHERE s.active = 1 ORDER BY c.sort_order, s.name]]) or {}
    }
end

Public.reviews = function(xp)
    local stats = MySQL.single.await('SELECT COUNT(*) AS total, AVG(rating) AS avg FROM bs_reviews WHERE hidden = 0') or {}
    local list = MySQL.query.await(([[
        SELECT r.id, r.author, r.rating, r.comment, r.service_id, s.name AS service, %s AS date
        FROM bs_reviews r LEFT JOIN bs_services s ON s.id = r.service_id
        WHERE r.hidden = 0 ORDER BY r.id DESC LIMIT 60]]):format((DATE:gsub('created_at', 'r.created_at')))) or {}
    local dist = { 0, 0, 0, 0, 0 }
    for _, r in ipairs(MySQL.query.await('SELECT rating, COUNT(*) AS c FROM bs_reviews WHERE hidden = 0 GROUP BY rating') or {}) do
        if dist[r.rating] then dist[r.rating] = r.c end
    end
    local mine = {}
    for _, r in ipairs(MySQL.query.await('SELECT service_id FROM bs_reviews WHERE identifier = ?', { xp.identifier }) or {}) do
        mine[#mine + 1] = r.service_id
    end
    return {
        total = stats.total or 0, avg = stats.avg and tonumber(stats.avg) or 0,
        list = list, mine = mine, dist = dist,
        services = MySQL.query.await('SELECT id, name FROM bs_services WHERE active = 1 ORDER BY name') or {}
    }
end

Public.submitReview = function(xp, p, src)
    if not cooldown(src, 'review', Config.Cooldown.review) then return nil, 'Patientez quelques secondes.' end
    local rating = math.floor(tonumber(p.rating) or 0)
    if rating < 1 or rating > 5 then return nil, 'Choisissez une note de 1 à 5 étoiles.' end
    local comment = clean(p.comment, 500)
    if #comment < 3 then return nil, 'Ajoutez un petit commentaire.' end

    local serviceId = math.floor(tonumber(p.service_id) or 0)
    if serviceId > 0 and not MySQL.scalar.await('SELECT id FROM bs_services WHERE id = ? AND active = 1', { serviceId }) then
        return nil, 'Produit introuvable.'
    end
    if MySQL.scalar.await('SELECT id FROM bs_reviews WHERE identifier = ? AND service_id = ?', { xp.identifier, serviceId }) then
        return nil, 'Vous avez déjà donné votre avis pour ce produit.'
    end

    local id = MySQL.insert.await(
        'INSERT INTO bs_reviews (identifier, author, service_id, rating, comment) VALUES (?, ?, ?, ?, ?)',
        { xp.identifier, clean(xp.getName(), 100), serviceId, rating, comment })
    if not id then return nil, 'Avis déjà enregistré.' end

    logActivity(('Nouvel avis %d/5 de %s'):format(rating, xp.getName()))
    notifyAdmins('Nouvel avis', ('%s a laissé %d/5.'):format(xp.getName(), rating))
    return true
end

Public.myApplications = function(xp)
    return MySQL.query.await(([[
        SELECT id, status, response, %s AS date FROM bs_applications
        WHERE identifier = ? ORDER BY id DESC LIMIT 10]]):format(DATE), { xp.identifier }) or {}
end

Public.submitApplication = function(xp, p, src)
    if not cooldown(src, 'application', Config.Cooldown.application) then return nil, 'Patientez quelques secondes.' end
    local f = {
        fullname = clean(p.fullname, 100), phone = clean(p.phone, 30),
        reason = clean(p.reason, 800), availability = clean(p.availability, 400),
        experience = clean(p.experience, 800), motivation = clean(p.motivation, 800)
    }
    for _, v in pairs(f) do
        if v == '' then return nil, 'Tous les champs sont obligatoires.' end
    end
    if MySQL.scalar.await("SELECT id FROM bs_applications WHERE identifier = ? AND status = 'pending'", { xp.identifier }) then
        return nil, 'Vous avez déjà une candidature en attente.'
    end

    MySQL.insert.await([[
        INSERT INTO bs_applications (identifier, fullname, phone, reason, availability, experience, motivation)
        VALUES (?, ?, ?, ?, ?, ?, ?)]],
        { xp.identifier, f.fullname, f.phone, f.reason, f.availability, f.experience, f.motivation })

    logActivity(('Nouvelle candidature de %s'):format(f.fullname))
    notifyAdmins('Nouvelle candidature', ('%s souhaite rejoindre Burger Shot.'):format(f.fullname))
    return true
end

Public.submitRequest = function(xp, p, src)
    if not cooldown(src, 'request', Config.Cooldown.request) then return nil, 'Patientez quelques secondes.' end
    local fullname, phone, message = clean(p.fullname, 100), clean(p.phone, 30), clean(p.message, 600)
    if fullname == '' or phone == '' or #message < 5 then return nil, 'Complétez tous les champs.' end

    MySQL.insert.await('INSERT INTO bs_requests (identifier, fullname, phone, message) VALUES (?, ?, ?, ?)',
        { xp.identifier, fullname, phone, message })

    logActivity(('Demande client de %s'):format(fullname))
    notifyAdmins('Demande client', ('%s passe une commande.'):format(fullname))
    return true
end

-- ─────────────────────────────── Rendez-vous ───────────────────────────────

local APPT_ACTIVE = "('pending','confirmed')"

local function validDate(d)
    local y, m, day = tostring(d):match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    if not y then return false end
    y, m, day = tonumber(y), tonumber(m), tonumber(day)
    if m < 1 or m > 12 or day < 1 or day > 31 then return false end
    -- vérifie que la date existe vraiment (refuse par ex. le 31 février)
    local t = os.time({ year = y, month = m, day = day, hour = 12 })
    return t ~= nil and os.date('%Y-%m-%d', t) == d
end

local function validTime(t)
    local h, m = tostring(t):match('^(%d%d):(%d%d)$')
    if not h then return false end
    return tonumber(h) <= 23 and tonumber(m) <= 59
end

Public.myAppointments = function(xp)
    return MySQL.query.await(([[
        SELECT a.id, a.date_wanted, a.time_wanted, a.note, a.status, a.response, s.name AS service, %s AS date
        FROM bs_appointments a LEFT JOIN bs_services s ON s.id = a.service_id
        WHERE a.identifier = ? ORDER BY a.date_wanted DESC, a.time_wanted DESC LIMIT 30]]):format((DATE:gsub('created_at', 'a.created_at'))),
        { xp.identifier }) or {}
end

Public.submitAppointment = function(xp, p, src)
    if not cooldown(src, 'appointment', Config.Cooldown.appointment or 30) then return nil, 'Patientez quelques secondes.' end
    local fullname, phone, note = clean(p.fullname, 100), clean(p.phone, 30), clean(p.note, 400)
    local date, time = clean(p.date, 10), clean(p.time, 5)
    if fullname == '' or phone == '' then return nil, 'Indiquez votre nom et votre téléphone.' end
    if not validDate(date) then return nil, 'Date invalide.' end
    if not validTime(time) then return nil, 'Heure invalide.' end
    -- tolérance d'un jour pour les écarts de fuseau horaire serveur / joueur
    if date < os.date('%Y-%m-%d', os.time() - 86400) then return nil, 'Cette date est déjà passée.' end

    local serviceId = math.floor(tonumber(p.service_id) or 0)
    if serviceId > 0 and not MySQL.scalar.await('SELECT id FROM bs_services WHERE id = ? AND active = 1', { serviceId }) then
        return nil, 'Produit introuvable.'
    end

    local active = MySQL.scalar.await(
        'SELECT COUNT(*) FROM bs_appointments WHERE identifier = ? AND status IN ' .. APPT_ACTIVE, { xp.identifier }) or 0
    if active >= (Config.MaxActiveAppointments or 3) then
        return nil, 'Vous avez déjà trop de rendez-vous en cours. Annulez-en un ou attendez qu\'il soit traité.'
    end
    if MySQL.scalar.await(
        'SELECT id FROM bs_appointments WHERE identifier = ? AND date_wanted = ? AND time_wanted = ? AND status IN ' .. APPT_ACTIVE,
        { xp.identifier, date, time }) then
        return nil, 'Vous avez déjà un rendez-vous à cette date et cette heure.'
    end

    MySQL.insert.await([[
        INSERT INTO bs_appointments (identifier, fullname, phone, service_id, date_wanted, time_wanted, note)
        VALUES (?, ?, ?, ?, ?, ?, ?)]],
        { xp.identifier, fullname, phone, serviceId, date, time, note })

    logActivity(('Demande de RDV de %s (%s à %s)'):format(fullname, date, time))
    notifyAdmins('Nouveau rendez-vous', ('%s demande un RDV le %s à %s.'):format(fullname, date, time))
    return true
end

Public.cancelAppointment = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local a = MySQL.single.await(
        'SELECT fullname, date_wanted, time_wanted FROM bs_appointments WHERE id = ? AND identifier = ? AND status IN ' .. APPT_ACTIVE,
        { id, xp.identifier })
    if not a then return nil, 'Rendez-vous introuvable ou déjà clôturé.' end
    MySQL.update.await("UPDATE bs_appointments SET status = 'cancelled' WHERE id = ?", { id })
    logActivity(('%s a annulé son RDV du %s à %s'):format(a.fullname, a.date_wanted, a.time_wanted))
    notifyAdmins('Rendez-vous annulé', ('%s a annulé son RDV du %s à %s.'):format(a.fullname, a.date_wanted, a.time_wanted))
    return true
end

Public.notifications = function(xp)
    local list = MySQL.query.await(([[
        SELECT id, title, content, is_read, %s AS date FROM bs_notifications
        WHERE identifier = ? ORDER BY id DESC LIMIT 30]]):format(DATE), { xp.identifier }) or {}
    return list
end

Public.readNotifications = function(xp)
    MySQL.update.await('UPDATE bs_notifications SET is_read = 1 WHERE identifier = ?', { xp.identifier })
    return true
end

Public.unreadCount = function(xp)
    return MySQL.scalar.await('SELECT COUNT(*) FROM bs_notifications WHERE identifier = ? AND is_read = 0', { xp.identifier }) or 0
end

-- ═══════════════════════ ACTIONS ADMIN (patron + délégués) ═════════════════

Admin.stats = function()
    local count = function(q) return MySQL.scalar.await(q) or 0 end
    local review = MySQL.single.await('SELECT COUNT(*) AS total, AVG(rating) AS avg FROM bs_reviews WHERE hidden = 0') or {}
    return {
        applications = count('SELECT COUNT(*) FROM bs_applications'),
        pending      = count("SELECT COUNT(*) FROM bs_applications WHERE status = 'pending'"),
        accepted     = count("SELECT COUNT(*) FROM bs_applications WHERE status = 'accepted'"),
        refused      = count("SELECT COUNT(*) FROM bs_applications WHERE status = 'refused'"),
        newRequests  = count("SELECT COUNT(*) FROM bs_requests WHERE status = 'new'"),
        pendingRdv   = count("SELECT COUNT(*) FROM bs_appointments WHERE status = 'pending'"),
        upcomingRdv  = count("SELECT COUNT(*) FROM bs_appointments WHERE status = 'confirmed'"),
        reviews      = review.total or 0,
        avg          = review.avg and tonumber(review.avg) or 0,
        activity     = MySQL.query.await(("SELECT text, %s AS date FROM bs_activity ORDER BY id DESC LIMIT 12"):format(DATE)) or {},
        requests     = MySQL.query.await(("SELECT id, fullname, message, %s AS date FROM bs_requests WHERE status = 'new' ORDER BY id DESC LIMIT 5"):format(DATE)) or {}
    }
end

Admin.applications = function(_, p)
    local status = p.status
    local where, args = '', {}
    if status == 'pending' or status == 'accepted' or status == 'refused' then
        where, args = 'WHERE status = ?', { status }
    end
    return MySQL.query.await(([[
        SELECT id, fullname, phone, reason, availability, experience, motivation, status, response, decided_by,
               %s AS date FROM bs_applications %s ORDER BY (status = 'pending') DESC, id DESC LIMIT 100]]):format(DATE, where), args) or {}
end

Admin.decideApplication = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local decision = p.decision == 'accepted' and 'accepted' or (p.decision == 'refused' and 'refused' or nil)
    if id < 1 or not decision then return nil, 'Requête invalide.' end

    local app = MySQL.single.await("SELECT identifier, fullname FROM bs_applications WHERE id = ? AND status = 'pending'", { id })
    if not app then return nil, 'Candidature déjà traitée ou introuvable.' end

    local response = clean(p.response, 500)
    MySQL.update.await(
        'UPDATE bs_applications SET status = ?, response = ?, decided_by = ?, decided_at = NOW() WHERE id = ?',
        { decision, response, clean(xp.getName(), 100), id })

    local accepted = decision == 'accepted'
    logActivity(('Candidature de %s %s par %s'):format(app.fullname, accepted and 'acceptée' or 'refusée', xp.getName()))
    notifyPlayer(app.identifier,
        accepted and 'Candidature acceptée' or 'Candidature refusée',
        response ~= '' and response or (accepted and 'Bienvenue chez Burger Shot !' or 'Votre candidature n\'a pas été retenue.'))
    return true
end

Admin.adminServices = function()
    return {
        categories = MySQL.query.await('SELECT id, name FROM bs_categories ORDER BY sort_order, name') or {},
        services   = MySQL.query.await([[
            SELECT s.id, s.category_id, c.name AS category, s.name, s.description, s.price, s.conditions, s.active
            FROM bs_services s JOIN bs_categories c ON c.id = s.category_id
            ORDER BY c.sort_order, s.name]]) or {}
    }
end

Admin.saveService = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local catId = math.floor(tonumber(p.category_id) or 0)
    local name, desc, cond = clean(p.name, 100), clean(p.description, 500), clean(p.conditions, 300)
    local price = math.floor(tonumber(p.price) or -1)
    if name == '' then return nil, 'Le nom est obligatoire.' end
    if price < 0 or price > 10000000 then return nil, 'Prix invalide.' end
    if not MySQL.scalar.await('SELECT id FROM bs_categories WHERE id = ?', { catId }) then return nil, 'Catégorie invalide.' end
    local active = p.active and 1 or 0

    if id > 0 then
        MySQL.update.await(
            'UPDATE bs_services SET category_id=?, name=?, description=?, price=?, conditions=?, active=? WHERE id=?',
            { catId, name, desc, price, cond, active, id })
        logActivity(('%s a modifié le produit « %s »'):format(xp.getName(), name))
    else
        MySQL.insert.await(
            'INSERT INTO bs_services (category_id, name, description, price, conditions, active) VALUES (?, ?, ?, ?, ?, ?)',
            { catId, name, desc, price, cond, active })
        logActivity(('%s a ajouté le produit « %s »'):format(xp.getName(), name))
    end
    return true
end

Admin.toggleService = function(_, p)
    MySQL.update.await('UPDATE bs_services SET active = 1 - active WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true
end

Admin.deleteService = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local name = MySQL.scalar.await('SELECT name FROM bs_services WHERE id = ?', { id })
    if not name then return nil, 'Produit introuvable.' end
    MySQL.update.await('DELETE FROM bs_services WHERE id = ?', { id })
    logActivity(('%s a supprimé le produit « %s »'):format(xp.getName(), name))
    return true
end

Admin.saveCategory = function(_, p)
    local name = clean(p.name, 80)
    if name == '' then return nil, 'Nom de catégorie obligatoire.' end
    if MySQL.scalar.await('SELECT id FROM bs_categories WHERE name = ?', { name }) then return nil, 'Cette catégorie existe déjà.' end
    local order = (MySQL.scalar.await('SELECT COALESCE(MAX(sort_order), 0) FROM bs_categories') or 0) + 1
    MySQL.insert.await('INSERT INTO bs_categories (name, sort_order) VALUES (?, ?)', { name, order })
    return true
end

Admin.deleteCategory = function(_, p)
    local id = math.floor(tonumber(p.id) or 0)
    if (MySQL.scalar.await('SELECT COUNT(*) FROM bs_services WHERE category_id = ?', { id }) or 0) > 0 then
        return nil, 'Déplacez ou supprimez d\'abord les produits de cette catégorie.'
    end
    MySQL.update.await('DELETE FROM bs_categories WHERE id = ?', { id })
    return true
end

Admin.adminAppointments = function(_, p)
    local status = p.status
    local where, args = '', {}
    if status == 'pending' or status == 'confirmed' or status == 'refused' or status == 'done' or status == 'cancelled' then
        where, args = 'WHERE a.status = ?', { status }
    end
    return MySQL.query.await(([[
        SELECT a.id, a.fullname, a.phone, a.date_wanted, a.time_wanted, a.note, a.status, a.response, a.decided_by,
               s.name AS service, %s AS date
        FROM bs_appointments a LEFT JOIN bs_services s ON s.id = a.service_id %s
        ORDER BY (a.status = 'pending') DESC, (a.status = 'confirmed') DESC, a.date_wanted, a.time_wanted LIMIT 100]])
        :format((DATE:gsub('created_at', 'a.created_at')), where), args) or {}
end

Admin.decideAppointment = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local decision = p.decision
    if id < 1 or (decision ~= 'confirmed' and decision ~= 'refused' and decision ~= 'done') then
        return nil, 'Requête invalide.'
    end

    local a = MySQL.single.await('SELECT identifier, fullname, date_wanted, time_wanted, status FROM bs_appointments WHERE id = ?', { id })
    if not a then return nil, 'Rendez-vous introuvable.' end
    if a.status == 'cancelled' then return nil, 'Ce rendez-vous a été annulé par le client.' end
    if decision == 'done' and a.status ~= 'confirmed' then return nil, 'Confirmez d\'abord le rendez-vous.' end
    if decision ~= 'done' and a.status ~= 'pending' then return nil, 'Rendez-vous déjà traité.' end

    local response = clean(p.response, 400)
    MySQL.update.await('UPDATE bs_appointments SET status = ?, response = ?, decided_by = ? WHERE id = ?',
        { decision, response, clean(xp.getName(), 100), id })

    local when = ('%s à %s'):format(a.date_wanted, a.time_wanted)
    if decision == 'confirmed' then
        logActivity(('RDV de %s confirmé pour le %s par %s'):format(a.fullname, when, xp.getName()))
        notifyPlayer(a.identifier, 'Rendez-vous confirmé',
            response ~= '' and response or ('Votre rendez-vous du %s est confirmé.'):format(when))
    elseif decision == 'refused' then
        logActivity(('RDV de %s refusé par %s'):format(a.fullname, xp.getName()))
        notifyPlayer(a.identifier, 'Rendez-vous refusé',
            response ~= '' and response or ('Votre demande de rendez-vous du %s n\'a pas pu être acceptée.'):format(when))
    else
        logActivity(('RDV de %s marqué terminé par %s'):format(a.fullname, xp.getName()))
    end
    return true
end

Admin.deleteAppointment = function(_, p)
    MySQL.update.await('DELETE FROM bs_appointments WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true
end

Admin.adminMenuLinks = function()
    return MySQL.query.await('SELECT id, title, url, active FROM bs_menu_links ORDER BY sort_order, id') or {}
end

Admin.saveMenuLink = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local title, url = clean(p.title, 80), cleanUrl(p.url)
    if title == '' then return nil, 'Le titre est obligatoire.' end
    if not url then return nil, 'Lien invalide : il doit commencer par https:// et ne pas contenir d\'espace.' end
    local active = p.active and 1 or 0

    if id > 0 then
        if not MySQL.scalar.await('SELECT id FROM bs_menu_links WHERE id = ?', { id }) then return nil, 'Lien introuvable.' end
        MySQL.update.await('UPDATE bs_menu_links SET title = ?, url = ?, active = ? WHERE id = ?', { title, url, active, id })
        logActivity(('%s a modifié le lien de menu « %s »'):format(xp.getName(), title))
    else
        local count = MySQL.scalar.await('SELECT COUNT(*) FROM bs_menu_links') or 0
        if count >= (Config.MaxMenuLinks or 12) then
            return nil, ('Maximum %d liens de menu. Supprimez-en un avant d\'en ajouter.'):format(Config.MaxMenuLinks or 12)
        end
        local order = (MySQL.scalar.await('SELECT COALESCE(MAX(sort_order), 0) FROM bs_menu_links') or 0) + 1
        MySQL.insert.await('INSERT INTO bs_menu_links (title, url, sort_order, active) VALUES (?, ?, ?, ?)', { title, url, order, active })
        logActivity(('%s a ajouté le lien de menu « %s »'):format(xp.getName(), title))
    end
    return true
end

Admin.deleteMenuLink = function(xp, p)
    local id = math.floor(tonumber(p.id) or 0)
    local title = MySQL.scalar.await('SELECT title FROM bs_menu_links WHERE id = ?', { id })
    if not title then return nil, 'Lien introuvable.' end
    MySQL.update.await('DELETE FROM bs_menu_links WHERE id = ?', { id })
    logActivity(('%s a supprimé le lien de menu « %s »'):format(xp.getName(), title))
    return true
end

Admin.moveMenuLink = function(_, p)
    local id = math.floor(tonumber(p.id) or 0)
    local rows = MySQL.query.await('SELECT id FROM bs_menu_links ORDER BY sort_order, id') or {}
    local idx
    for i, r in ipairs(rows) do if r.id == id then idx = i end end
    if not idx then return nil, 'Lien introuvable.' end
    local j = p.dir == 'up' and idx - 1 or idx + 1
    if j < 1 or j > #rows then return true end
    rows[idx], rows[j] = rows[j], rows[idx]
    for i, r in ipairs(rows) do
        MySQL.update.await('UPDATE bs_menu_links SET sort_order = ? WHERE id = ?', { i, r.id })
    end
    return true
end

Admin.adminReviews = function()
    return MySQL.query.await(([[
        SELECT r.id, r.author, r.rating, r.comment, r.hidden, s.name AS service, %s AS date
        FROM bs_reviews r LEFT JOIN bs_services s ON s.id = r.service_id
        ORDER BY r.id DESC LIMIT 100]]):format((DATE:gsub('created_at', 'r.created_at')))) or {}
end

Admin.toggleReview = function(_, p)
    MySQL.update.await('UPDATE bs_reviews SET hidden = 1 - hidden WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true
end

Admin.deleteReview = function(_, p)
    MySQL.update.await('DELETE FROM bs_reviews WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true
end

Admin.adminRequests = function()
    return MySQL.query.await(("SELECT id, fullname, phone, message, status, %s AS date FROM bs_requests ORDER BY (status = 'new') DESC, id DESC LIMIT 100"):format(DATE)) or {}
end

Admin.doneRequest = function(_, p)
    MySQL.update.await("UPDATE bs_requests SET status = 'done' WHERE id = ?", { math.floor(tonumber(p.id) or 0) })
    return true
end

Admin.deleteRequest = function(_, p)
    MySQL.update.await('DELETE FROM bs_requests WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true
end

Admin.saveSettings = function(xp, p)
    for key, max in pairs(SETTING_KEYS) do
        if p[key] ~= nil then
            local value = clean(p[key], max)
            if key == 'name' and value == '' then return nil, 'Le nom de l\'entreprise est obligatoire.' end
            MySQL.query.await('INSERT INTO bs_settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', { key, value })
        end
    end
    logActivity(('%s a modifié les informations de l\'entreprise'):format(xp.getName()))
    return true
end

Admin.saveNews = function(xp, p)
    local kind = p.kind == 'news' and 'news' or 'announcement'
    local title, content = clean(p.title, 120), clean(p.content, 800)
    if title == '' or content == '' then return nil, 'Titre et contenu obligatoires.' end
    MySQL.insert.await('INSERT INTO bs_news (kind, title, content) VALUES (?, ?, ?)', { kind, title, content })
    logActivity(('%s a publié « %s »'):format(xp.getName(), title))
    return true
end

Admin.deleteNews = function(_, p)
    MySQL.update.await('DELETE FROM bs_news WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true
end

-- Gestion des accès : réservée au patron uniquement
Admin.permissions = function(xp)
    if not isBoss(xp) then return nil, 'Réservé au patron.' end
    return MySQL.query.await(("SELECT identifier, label, granted_by, %s AS date FROM bs_permissions ORDER BY created_at DESC"):format(DATE)) or {}
end

Admin.grantAccess = function(xp, p)
    if not isBoss(xp) then return nil, 'Réservé au patron.' end
    local target = ESX.GetPlayerFromId(math.floor(tonumber(p.serverId) or 0))
    if not target then return nil, 'Aucun joueur connecté avec cet ID.' end
    if isBoss(target) then return nil, 'Ce joueur est déjà patron.' end
    MySQL.query.await(
        'INSERT INTO bs_permissions (identifier, label, granted_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label)',
        { target.identifier, clean(target.getName(), 100), clean(xp.getName(), 100) })
    Perms[target.identifier] = true
    logActivity(('%s a donné l\'accès administrateur à %s'):format(xp.getName(), target.getName()))
    return true
end

Admin.revokeAccess = function(xp, p)
    if not isBoss(xp) then return nil, 'Réservé au patron.' end
    local identifier = clean(p.identifier, 80)
    MySQL.update.await('DELETE FROM bs_permissions WHERE identifier = ?', { identifier })
    Perms[identifier] = nil
    logActivity(('%s a retiré un accès administrateur'):format(xp.getName()))
    return true
end

-- ─────────────────────────────── Point d'entrée ────────────────────────────

ESX.RegisterServerCallback('bs:api', function(src, cb, action, payload)
    if not BS_READY then return cb({ ok = false, error = 'Service en cours de démarrage, réessayez.' }) end

    local xp = ESX.GetPlayerFromId(src)
    if not xp then return cb({ ok = false, error = 'Joueur introuvable.' }) end

    local params = type(payload) == 'table' and payload or {}
    local fn = type(action) == 'string' and Public[action] or nil

    if not fn and type(action) == 'string' and Admin[action] then
        -- vérification d'autorisation côté serveur, jamais côté interface
        if not isAdmin(xp) then
            print(('^3[burgershot_app] Accès refusé : %s (%s) a tenté « %s »^7'):format(xp.getName(), xp.identifier, action))
            return cb({ ok = false, error = 'Accès refusé.' })
        end
        fn = Admin[action]
    end
    if not fn then return cb({ ok = false, error = 'Action inconnue.' }) end

    local ok, res, err = pcall(fn, xp, params, src)
    if not ok then
        print(('^1[burgershot_app] Erreur dans « %s » : %s^7'):format(action, tostring(res)))
        return cb({ ok = false, error = 'Erreur interne du serveur.' })
    end
    if res == nil then return cb({ ok = false, error = err or 'Erreur.' }) end
    cb({ ok = true, data = res })
end)

AddEventHandler('burgershot_app:dbReady', loadPerms)

Config = {}

-- Identifiant interne de l'application (ne pas changer après installation)
Config.AppIdentifier = 'burgershot'
Config.AppName       = 'Burger Shot'
Config.AppDescription = 'Menu, tarifs, avis, rendez-vous et recrutement de Burger Shot'

-- Compatibilité : mettre false pour désactiver un des deux supports
Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet

-- LB Tablet : false = chemin « html/index.html » (recommandé par la doc LB Tablet).
-- Si l'app reste blanche sur la tablette, essayer true.
Config.TabletUiWithResourceName = false

-- false = l'app n'est PAS imposée : le joueur l'installe depuis l'App Store du téléphone
-- et peut ensuite la SUPPRIMER comme n'importe quelle autre application.
-- true  = l'app est préinstallée chez tous les joueurs (et ne se désinstalle pas).
Config.DefaultApp = false

-- Lien de l'image du menu (affichée dans l'onglet Menu, agrandissable)
Config.MenuImage = 'https://cdn.spirit-gta.com/web/1793564135691-d0caf209.png'

-- Symbole de monnaie affiché dans l'interface
Config.Currency = '$'

-- Accès patron (vérifié côté serveur)
Config.Job            = 'burgershot'  -- nom du job ESX de Burger Shot
Config.MinGrade       = 5           -- grade minimum considéré comme « patron »
Config.BossGradeName  = 'boss'      -- ou nom du grade patron dans ta table job_grades

-- Propriétaires forcés (par identifier ESX), utile pour les tests
-- Exemple : ['license:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'] = true
Config.Owners = {}

-- Anti-spam (secondes entre deux envois du même joueur)
Config.Cooldown = {
    application = 30,
    request     = 30,
    review      = 15,
    appointment = 30
}

-- Rendez-vous : nombre maximum de RDV « en attente / confirmés » par joueur
Config.MaxActiveAppointments = 3

-- Menu : nombre maximum de liens (affiches / pages) que le patron peut publier
Config.MaxMenuLinks = 12

-- Si le joueur n'a pas de téléphone équipé, afficher une notification ESX classique
Config.EsxNotifyFallback = true

-- Valeurs par défaut créées uniquement si la base est vide
Config.DefaultSettings = {
    name        = 'Burger Shot',
    description = 'Burger Shot : burgers, menus et boissons préparés avec soin, sur place ou à emporter.',
    phone       = '',
    email       = '',
    hours       = 'Lundi - Vendredi : 10h - 22h\nSamedi - Dimanche : 14h - 22h'
}

Config.DefaultCategories = {
    'Burgers',
    'Menus',
    'Accompagnements',
    'Boissons',
    'Desserts',
    'Offres spéciales'
}

-- Exemples de départ, tous modifiables ensuite dans Espace patron > Carte
-- { catégorie, nom, description, prix, conditions }
Config.DefaultServices = {
    { 'Burgers',         'Bleeder',            'Le classique : steak, cheddar, salade, sauce maison.',       12, '' },
    { 'Burgers',         'Heart Stopper',      'Double steak, bacon croustillant et fromage fondu.',         18, '' },
    { 'Burgers',         'Money Shot',         'Notre burger signature, généreux et très gourmand.',         16, '' },
    { 'Menus',           'Menu Bleeder',       'Bleeder + frites + boisson au choix.',                       18, 'Sur place ou à emporter.' },
    { 'Menus',           'Menu Heart Stopper', 'Heart Stopper + frites + boisson au choix.',                 24, '' },
    { 'Accompagnements', 'Frites',             'Frites dorées et croustillantes.',                            5, '' },
    { 'Accompagnements', 'Onion rings',        'Rondelles d\'oignon panées.',                                6, '' },
    { 'Boissons',        'Soda',               'Cola, limonade ou thé glacé.',                                3, '' },
    { 'Desserts',        'Milkshake',          'Vanille, chocolat ou fraise.',                                6, '' },
    { 'Offres spéciales','Menu duo',           '2 burgers + 2 frites + 2 boissons.',                         34, 'Offre limitée.' }
}

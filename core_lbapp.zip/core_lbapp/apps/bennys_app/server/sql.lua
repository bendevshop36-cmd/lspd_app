-- Installation automatique de la base de données.
-- Exécutée à chaque lancement de la ressource : crée les tables manquantes
-- (sql/install.sql) puis insère les données par défaut si elles n'existent pas.

BN_READY = false

local RESOURCE = GetCurrentResourceName()

local function runInstallFile()
    local raw = LoadResourceFile(RESOURCE, APP_PATH .. 'sql/install.sql')
    if not raw or raw == '' then
        print(('^1[bennys_app] sql/install.sql introuvable ou vide^7'))
        return false
    end

    -- retire les commentaires « -- ... » puis découpe sur les points-virgules
    raw = raw:gsub('%-%-[^\n]*', '')

    local count = 0
    for statement in raw:gmatch('[^;]+') do
        local stmt = (statement:gsub('^%s+', ''):gsub('%s+$', ''))
        if stmt ~= '' then
            local ok, err = pcall(MySQL.query.await, stmt)
            if not ok then
                print(('^1[bennys_app] Erreur SQL : %s^7'):format(tostring(err)))
                return false
            end
            count = count + 1
        end
    end

    print(('^2[bennys_app] Base de données prête (%d requêtes exécutées)^7'):format(count))
    return true
end

local function seedDefaults()
    -- Paramètres : n'écrase jamais ce que le patron a modifié
    for k, v in pairs(Config.DefaultSettings) do
        MySQL.query.await('INSERT IGNORE INTO bn_settings (k, v) VALUES (?, ?)', { k, v })
    end

    -- Catégories et prestations : uniquement si la table est vide
    local catCount = MySQL.scalar.await('SELECT COUNT(*) FROM bn_categories') or 0
    if catCount == 0 then
        for i, name in ipairs(Config.DefaultCategories) do
            MySQL.insert.await('INSERT INTO bn_categories (name, sort_order) VALUES (?, ?)', { name, i })
        end
    end

    local svcCount = MySQL.scalar.await('SELECT COUNT(*) FROM bn_services') or 0
    if svcCount == 0 then
        for _, s in ipairs(Config.DefaultServices) do
            local catId = MySQL.scalar.await('SELECT id FROM bn_categories WHERE name = ?', { s[1] })
            if catId then
                MySQL.insert.await(
                    'INSERT INTO bn_services (category_id, name, description, price, conditions) VALUES (?, ?, ?, ?, ?)',
                    { catId, s[2], s[3], s[4], s[5] }
                )
            end
        end
    end
end

MySQL.ready(function()
    if runInstallFile() then
        local ok, err = pcall(seedDefaults)
        if not ok then
            print(('^1[bennys_app] Erreur données par défaut : %s^7'):format(tostring(err)))
        end
        BN_READY = true
        TriggerEvent('bennys_app:dbReady')
    else
        print('^1[bennys_app] Installation SQL échouée : l\'application reste désactivée.^7')
    end
end)

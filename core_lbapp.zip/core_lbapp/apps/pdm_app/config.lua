Config = {}

Config.AppIdentifier  = 'pdm'
Config.AppName        = 'PDM'
Config.AppDescription = 'Catalogue Premium Deluxe Motorsport : tous les véhicules et leurs prix'

Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet
Config.TabletUiWithResourceName = false  -- mettre true si l'app reste blanche sur la tablette

-- false = les joueurs installent l'app depuis l'App Store du téléphone (et peuvent la supprimer)
Config.DefaultApp = false

-- Infos du concessionnaire (laisser '' pour masquer une ligne)
Config.Shop = {
    name    = 'Premium Deluxe Motorsport',
    tagline = 'Le catalogue complet de la concession',
    phone   = '',
    address = '',
    hours   = ''
}

Config.Currency = '$'

-- Les images viennent de ce lien (%s = nom du modèle). Image par véhicule possible avec image = 'https://...'
Config.ImageUrl = 'https://docs.fivem.net/vehicles/%s.webp'

-- { modèle (nom de spawn), marque, nom, catégorie, prix, [places], [image] }
-- Ajoute / supprime des lignes librement : les catégories se créent toutes seules.
Config.Vehicles = {
    -- Compactes
    { 'blista',       'Dinka',       'Blista',          'Compactes',        15000,   4 },
    { 'brioso',       'Grotti',      'Brioso R/A',      'Compactes',        155000,  2 },
    { 'issi2',        'Weeny',       'Issi',            'Compactes',        18000,   4 },
    { 'prairie',      'Bollokan',    'Prairie',         'Compactes',        30000,   4 },
    -- Berlines
    { 'asea',         'Declasse',    'Asea',            'Berlines',         9000,    4 },
    { 'premier',      'Declasse',    'Premier',         'Berlines',         10000,   4 },
    { 'stanier',      'Vapid',       'Stanier',         'Berlines',         10000,   4 },
    { 'fugitive',     'Cheval',      'Fugitive',        'Berlines',         24000,   4 },
    { 'tailgater',    'Obey',        'Tailgater',       'Berlines',         55000,   4 },
    { 'schafter2',    'Benefactor',  'Schafter',        'Berlines',         65000,   4 },
    -- SUV
    { 'granger',      'Declasse',    'Granger',         'SUV',              35000,   8 },
    { 'cavalcade',    'Albany',      'Cavalcade',       'SUV',              60000,   4 },
    { 'patriot',      'Mammoth',     'Patriot',         'SUV',              70000,   4 },
    { 'baller',       'Gallivanter', 'Baller',          'SUV',              90000,   4 },
    { 'xls',          'Benefactor',  'XLS',             'SUV',              253000,  4 },
    -- Coupés
    { 'jackal',       'Ocelot',      'Jackal',          'Coupés',           60000,   2 },
    { 'zion',         'Übermacht',   'Zion',            'Coupés',           60000,   2 },
    { 'oracle2',      'Übermacht',   'Oracle',          'Coupés',           80000,   4 },
    { 'felon',        'Lampadati',   'Felon',           'Coupés',           90000,   2 },
    { 'exemplar',     'Dewbauche',   'Exemplar',        'Coupés',           205000,  2 },
    -- Muscle cars
    { 'sabregt',      'Declasse',    'Sabre Turbo',     'Muscle',           15000,   2 },
    { 'ruiner',       'Imponte',     'Ruiner',          'Muscle',           19000,   2 },
    { 'vigero',       'Declasse',    'Vigero',          'Muscle',           21000,   2 },
    { 'gauntlet',     'Bravado',     'Gauntlet',        'Muscle',           32000,   2 },
    { 'dominator',    'Vapid',       'Dominator',       'Muscle',           35000,   2 },
    { 'dukes',        'Imponte',     'Dukes',           'Muscle',           62000,   2 },
    -- Sportives classiques
    { 'monroe',       'Pegassi',     'Monroe',          'Sportives classiques', 490000, 2 },
    { 'stinger',      'Grotti',      'Stinger',         'Sportives classiques', 850000, 2 },
    { 'ztype',        'Albany',      'Z-Type',          'Sportives classiques', 950000, 2 },
    { 'btype',        'Albany',      'Roosevelt',       'Sportives classiques', 982000, 2 },
    { 'torero',       'Pegassi',     'Torero',          'Sportives classiques', 998000, 2 },
    -- Sportives
    { 'buffalo',      'Bravado',     'Buffalo',         'Sportives',        35000,   4 },
    { 'elegy2',       'Annis',       'Elegy RH8',       'Sportives',        95000,   2 },
    { 'comet2',       'Pfister',     'Comet',           'Sportives',        100000,  2 },
    { 'banshee',      'Bravado',     'Banshee',         'Sportives',        105000,  2 },
    { 'feltzer2',     'Benefactor',  'Feltzer',         'Sportives',        130000,  2 },
    { 'ninef',        'Obey',        '9F',              'Sportives',        130000,  2 },
    { 'carbonizzare', 'Grotti',      'Carbonizzare',    'Sportives',        195000,  2 },
    { 'jester',       'Dinka',       'Jester',          'Sportives',        240000,  2 },
    { 'massacro',     'Dewbauche',   'Massacro',        'Sportives',        275000,  2 },
    -- Supersportives
    { 'bullet',       'Vapid',       'Bullet',          'Supersportives',   155000,  2 },
    { 'vacca',        'Pegassi',     'Vacca',           'Supersportives',   240000,  2 },
    { 'infernus',     'Pegassi',     'Infernus',        'Supersportives',   440000,  2 },
    { 'turismor',     'Grotti',      'Turismo R',       'Supersportives',   500000,  2 },
    { 'cheetah',      'Grotti',      'Cheetah',         'Supersportives',   650000,  2 },
    { 'zentorno',     'Pegassi',     'Zentorno',        'Supersportives',   725000,  2 },
    { 'entityxf',     'Överflöd',    'Entity XF',       'Supersportives',   795000,  2 },
    { 'adder',        'Truffade',    'Adder',           'Supersportives',   1000000, 2 },
    { 'osiris',       'Pegassi',     'Osiris',          'Supersportives',   1950000, 2 },
    { 't20',           'Progen',      'T20',             'Supersportives',   2200000, 2 },
    -- Motos
    { 'faggio',       'Pegassi',     'Faggio',          'Motos',            4000,    2 },
    { 'sanchez',      'Maibatsu',    'Sanchez',         'Motos',            8000,    2 },
    { 'akuma',        'Dinka',       'Akuma',           'Motos',            9000,    2 },
    { 'pcj',          'Shitzu',      'PCJ 600',         'Motos',            9000,    2 },
    { 'double',       'Dinka',       'Double-T',        'Motos',            12000,   2 },
    { 'bati',         'Pegassi',     'Bati 801',        'Motos',            15000,   2 },
    { 'hexer',        'LCC',         'Hexer',           'Motos',            15000,   2 },
    -- Tout-terrain
    { 'rebel',        'Karin',       'Rebel',           'Tout-terrain',     22000,   2 },
    { 'bodhi2',       'Canis',       'Bodhi',           'Tout-terrain',     25000,   2 },
    { 'sandking',     'Vapid',       'Sandking XL',     'Tout-terrain',     38000,   4 },
    { 'bifta',        'BF',          'Bifta',           'Tout-terrain',     75000,   2 },
    { 'kamacho',      'Canis',       'Kamacho',         'Tout-terrain',     345000,  4 }
}

-- Installation automatique de la base de données (BCSO).
-- Exécutée à chaque lancement : crée les tables manquantes (sql/install.sql),
-- puis prévient server/main.lua (évènement bcso_app:dbReady) qui charge le cache.

BCSO_SQL_READY = false

local RESOURCE = GetCurrentResourceName()

local function runInstallFile()
    local raw = LoadResourceFile(RESOURCE, APP_PATH .. 'sql/install.sql')
    if not raw or raw == '' then
        print('^1[bcso_app] sql/install.sql introuvable ou vide^7')
        return false
    end

    -- retire les commentaires « -- ... » puis découpe sur les points-virgules
    raw = raw:gsub('%-%-[^\n]*', '')

    local count = 0
    for statement in raw:gmatch('[^;]+') do
        local stmt = (statement:gsub('^%s+', ''):gsub('%s+$', ''))
        if stmt ~= '' then
            local ok, err = pcall(MySQL.query.await, stmt)
            if not ok then
                print(('^1[bcso_app] Erreur SQL : %s^7'):format(tostring(err)))
                return false
            end
            count = count + 1
        end
    end

    print(('^2[bcso_app] Tables prêtes (%d requêtes exécutées)^7'):format(count))
    return true
end

MySQL.ready(function()
    if runInstallFile() then
        BCSO_SQL_READY = true
        TriggerEvent('bcso_app:dbReady')
    else
        print('^1[bcso_app] Installation SQL échouée : l\'application reste désactivée.^7')
    end
end)

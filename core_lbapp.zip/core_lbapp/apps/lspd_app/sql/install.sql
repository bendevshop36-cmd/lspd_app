-- Application LSPD : installation (MySQL / MariaDB, oxmysql)
CREATE TABLE IF NOT EXISTS `lspd_settings` (
  `k` VARCHAR(64) NOT NULL PRIMARY KEY,   -- defcon, recruit, info:<clé>
  `v` LONGTEXT NOT NULL,                  -- JSON
  `updated_at` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_announcements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(120) NOT NULL,
  `description` TEXT NOT NULL,
  `category` VARCHAR(40) NOT NULL,
  `author` VARCHAR(80) NOT NULL,
  `image` VARCHAR(500) NULL,
  `published` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` INT NOT NULL,
  `updated_at` INT NOT NULL,
  INDEX (`published`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `identifier` VARCHAR(80) NOT NULL,
  `full_name` VARCHAR(80) NOT NULL,
  `phone` VARCHAR(30) NOT NULL,
  `age` SMALLINT NOT NULL,
  `experience` TEXT NOT NULL,
  `motivation` TEXT NOT NULL,
  `availability` TEXT NOT NULL,
  `reason` TEXT NOT NULL,
  `status` ENUM('pending','review','accepted','refused') NOT NULL DEFAULT 'pending',
  `response` TEXT NULL,
  `reviewed_by` VARCHAR(80) NULL,
  `created_at` INT NOT NULL,
  `updated_at` INT NOT NULL,
  INDEX (`identifier`), INDEX (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `identifier` VARCHAR(80) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `action` VARCHAR(60) NOT NULL,
  `details` TEXT NULL,
  `created_at` INT NOT NULL,
  INDEX (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

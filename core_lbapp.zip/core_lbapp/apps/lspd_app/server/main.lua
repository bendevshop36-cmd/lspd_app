-- LSPD App : serveur. Toute permission est vérifiée ici ; le client n'est jamais cru.
local ESX = exports['es_extended']:getSharedObject()
local cache, lastReq, lastApply = {}, {}, {}
local ready = false
local H = {}  -- handlers : H[action](src, payload) -> { ok, ... }

-- ───────────── Utilitaires ─────────────
local function fail(msg) return { ok = false, error = msg } end

local function clean(v, d)
  d = d or 0
  local t = type(v)
  if t == 'string' then return v:sub(1, Config.MaxText) end
  if t == 'number' or t == 'boolean' then return v end
  if t == 'table' and d < 3 then
    local o, n = {}, 0
    for k, x in pairs(v) do
      n = n + 1; if n > 60 then break end
      if type(k) == 'string' or type(k) == 'number' then o[k] = clean(x, d + 1) end
    end
    return o
  end
  return nil
end

local function str(v, max, min)
  if type(v) ~= 'string' then return nil end
  v = v:gsub('^%s+', ''):gsub('%s+$', '')
  if #v < (min or 1) or #v > max then return nil end
  return v
end

local function getPerms(src)
  local p = { access = false, announcements = false, recruitment = false, info = false, defcon = false, history = false }
  local xp = ESX.GetPlayerFromId(src)
  if not xp then return p, nil end
  local job = xp.job or {}
  if Config.PoliceJobs[job.name] then
    local g = tonumber(job.grade) or 0
    for k, min in pairs(Config.MinGrade) do p[k] = g >= min end
    -- Le patron (grade ESX "boss" par défaut) a toutes les permissions, quel que soit son numéro de grade
    if Config.BossGradeNames[job.grade_name] then for k in pairs(Config.MinGrade) do p[k] = true end end
  end
  if Config.AdminGroups[xp.getGroup()] then for k in pairs(Config.MinGrade) do p[k] = true end end
  for k in pairs(Config.MinGrade) do if p[k] then p.access = true end end
  return p, xp
end

local function setting(k) return cache[k] end
local function saveSetting(k, v)
  cache[k] = v
  MySQL.query.await('INSERT INTO lspd_settings (k,v,updated_at) VALUES (?,?,?) ON DUPLICATE KEY UPDATE v=VALUES(v), updated_at=VALUES(updated_at)',
    { k, json.encode(v), os.time() })
end

local function log(xp, action, details)
  MySQL.insert('INSERT INTO lspd_logs (identifier,name,action,details,created_at) VALUES (?,?,?,?,?)',
    { xp.identifier, xp.getName(), action, details and json.encode(details) or nil, os.time() })
end

-- Niveaux DEFCON : valeurs de config.lua + personnalisation enregistrée en base (clés texte "1".."5")
local function levelsData()
  local out, ov = {}, setting('defcon_levels') or {}
  for n, base in pairs(Config.Defcon) do
    local o = ov[tostring(n)] or {}
    out[tostring(n)] = {
      title   = (type(o.title) == 'string' and o.title ~= '' and o.title) or base.title,
      color   = (type(o.color) == 'string' and o.color:match('^#%x%x%x%x%x%x$') and o.color) or base.color,
      message = (type(o.message) == 'string' and o.message ~= '' and o.message) or base.message or '',
    }
  end
  return out
end

-- ───────────── Notifications (exports documentés LB Phone / LB Tablet) ─────────────
local function started(res) return GetResourceState(res) == 'started' end

local function notifyAll(title, content)
  if Config.Phone and started('lb-phone') then
    pcall(function() exports['lb-phone']:NotifyEveryone('online', { app = Config.AppIdentifier, title = title, content = content }) end)
  end
  if Config.Tablet and started('lb-tablet') then
    pcall(function() exports['lb-tablet']:NotifyEveryone({ app = Config.AppIdentifier, title = title, content = content }, false) end)
  end
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
end

local function notifyPlayer(src, title, content)
  if Config.Phone and started('lb-phone') then
    pcall(function() exports['lb-phone']:SendNotification(src, { app = Config.AppIdentifier, title = title, content = content }) end)
  end
  if Config.Tablet and started('lb-tablet') then
    pcall(function() exports['lb-tablet']:SendNotification({ source = src, app = Config.AppIdentifier, title = title, content = content }) end)
  end
end

-- ───────────── Handlers publics ─────────────
H.getState = function(src)
  local perms, xp = getPerms(src)
  if not xp then return fail('Joueur introuvable') end
  local info = {}
  for key in pairs(Config.InfoKeys) do info[key] = setting('info:' .. key) end
  local ann = MySQL.query.await(
    'SELECT id,title,description,category,author,image,published,created_at FROM lspd_announcements '
    .. (perms.announcements and '' or 'WHERE published=1 ') .. 'ORDER BY created_at DESC LIMIT ?', { Config.MaxAnnouncements })
  local apps = MySQL.query.await(
    'SELECT id,status,response,created_at,updated_at FROM lspd_applications WHERE identifier=? ORDER BY id DESC LIMIT 5', { xp.identifier })
  return { ok = true, data = { defcon = setting('defcon'), levels = levelsData(), inverted = Config.DefconInverted == true, recruit = setting('recruit'), info = info,
    announcements = ann, applications = apps, perms = perms, categories = Config.Categories } }
end

H.apply = function(src, p)
  local _, xp = getPerms(src)
  if not xp then return fail('Joueur introuvable') end
  local rec = setting('recruit')
  if not rec.open then return fail('Les recrutements sont fermés.') end
  local t = os.time()
  if lastApply[xp.identifier] and t - lastApply[xp.identifier] < Config.ApplyCooldown then return fail('Veuillez patienter avant de renvoyer une candidature.') end
  local open = MySQL.scalar.await("SELECT COUNT(*) FROM lspd_applications WHERE identifier=? AND status IN ('pending','review')", { xp.identifier })
  if open > 0 then return fail('Vous avez déjà une candidature en cours.') end
  local name, phone = str(p.name, 80, 3), str(p.phone, 30, 3)
  local age = math.floor(tonumber(p.age) or 0)
  local exp, mot, av, why = str(p.experience, 1000), str(p.motivation, 1000), str(p.availability, 500), str(p.reason, 1000)
  if not (name and phone and exp and mot and av and why) then return fail('Tous les champs sont obligatoires.') end
  if age < (tonumber(rec.minAge) or 0) or age > 99 then return fail('Âge minimum requis : ' .. (rec.minAge or 0) .. ' ans.') end
  lastApply[xp.identifier] = t
  MySQL.insert.await('INSERT INTO lspd_applications (identifier,full_name,phone,age,experience,motivation,availability,reason,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
    { xp.identifier, name, phone, age, exp, mot, av, why, 'pending', t, t })
  return { ok = true }
end

-- ───────────── Administration ─────────────
H['admin:setDefcon'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.defcon then return fail('Permission refusée.') end
  local level = math.floor(tonumber(p.level) or 0)
  if not Config.Defcon[level] then return fail('Niveau invalide.') end
  local lv = levelsData()[tostring(level)]
  local d = { level = level, description = str(p.description, 600) or lv.message, updatedAt = os.time(), updatedBy = xp.getName() }
  saveSetting('defcon', d)
  log(xp, 'defcon', { level = level })
  if p.notify then notifyAll('DEFCON ' .. level .. ' – ' .. lv.title, d.description) else TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app') end
  return { ok = true }
end

H['admin:setRecruitment'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.recruitment then return fail('Permission refusée.') end
  local old, r = setting('recruit'), {}
  r.open = p.open == true
  r.minAge = math.max(0, math.min(99, math.floor(tonumber(p.minAge) or 0)))
  for _, k in ipairs({ 'conditions', 'availability', 'training', 'presentation' }) do r[k] = str(p[k] or '', Config.MaxText, 0) or '' end
  saveSetting('recruit', r)
  log(xp, 'recruitment', { open = r.open })
  if r.open ~= old.open then
    notifyAll('Recrutements LSPD', r.open and 'Les recrutements sont ouverts !' or 'Les recrutements sont fermés.')
  else TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app') end
  return { ok = true }
end

H['admin:listApplications'] = function(src)
  if not getPerms(src).recruitment then return fail('Permission refusée.') end
  return { ok = true, data = MySQL.query.await('SELECT * FROM lspd_applications ORDER BY id DESC LIMIT 100') }
end

H['admin:reviewApplication'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.recruitment then return fail('Permission refusée.') end
  local status = p.status
  if status ~= 'review' and status ~= 'accepted' and status ~= 'refused' then return fail('Statut invalide.') end
  local row = MySQL.single.await('SELECT identifier FROM lspd_applications WHERE id=?', { tonumber(p.id) })
  if not row then return fail('Candidature introuvable.') end
  MySQL.update.await('UPDATE lspd_applications SET status=?, response=?, reviewed_by=?, updated_at=? WHERE id=?',
    { status, str(p.response or '', 1000, 0), xp.getName(), os.time(), tonumber(p.id) })
  log(xp, 'application', { id = p.id, status = status })
  local labels = { review = 'en cours d\'étude', accepted = 'acceptée', refused = 'refusée' }
  local target = ESX.GetPlayerFromIdentifier(row.identifier)
  if target then notifyPlayer(target.source, 'Candidature LSPD', 'Votre candidature est ' .. labels[status] .. '.') end
  return { ok = true }
end

H['admin:saveAnnouncement'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.announcements then return fail('Permission refusée.') end
  local title, desc = str(p.title, 120), str(p.description, Config.MaxText)
  local valid = false
  for _, c in ipairs(Config.Categories) do if c == p.category then valid = true end end
  if not (title and desc and valid) then return fail('Titre, description et catégorie valides requis.') end
  local image = str(p.image or '', 500, 0)
  if image and image ~= '' and not image:match('^https?://') then return fail('L\'image doit être une URL http(s).') end
  local pub, t = p.published and 1 or 0, os.time()
  local id = tonumber(p.id)
  if id then
    MySQL.update.await('UPDATE lspd_announcements SET title=?,description=?,category=?,image=?,published=?,updated_at=? WHERE id=?',
      { title, desc, p.category, image ~= '' and image or nil, pub, t, id })
  else
    id = MySQL.insert.await('INSERT INTO lspd_announcements (title,description,category,author,image,published,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)',
      { title, desc, p.category, xp.getName(), image ~= '' and image or nil, pub, t, t })
  end
  log(xp, 'announcement', { id = id })
  if pub == 1 and p.notify then notifyAll(title, desc:sub(1, 200)) else TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app') end
  return { ok = true }
end

H['admin:deleteAnnouncement'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.announcements then return fail('Permission refusée.') end
  MySQL.update.await('DELETE FROM lspd_announcements WHERE id=?', { tonumber(p.id) })
  log(xp, 'announcement_delete', { id = p.id })
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
  return { ok = true }
end

H['admin:togglePublish'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.announcements then return fail('Permission refusée.') end
  MySQL.update.await('UPDATE lspd_announcements SET published = 1 - published, updated_at=? WHERE id=?', { os.time(), tonumber(p.id) })
  log(xp, 'announcement_toggle', { id = p.id })
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
  return { ok = true }
end

H['admin:saveInfo'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.info then return fail('Permission refusée.') end
  local kind = Config.InfoKeys[p.key]
  if not kind then return fail('Clé inconnue.') end
  local value
  if kind == 'text' then
    value = type(p.value) == 'string' and p.value:sub(1, Config.MaxText) or nil
  else
    if type(p.value) ~= 'table' then return fail('Format invalide.') end
    value = {}
    for i, e in ipairs(p.value) do
      if i > 40 then break end
      if type(e) == 'table' and type(e.t) == 'string' then
        value[#value + 1] = { t = e.t:sub(1, 120), d = type(e.d) == 'string' and e.d:sub(1, 600) or '' }
      end
    end
  end
  if value == nil then return fail('Valeur invalide.') end
  saveSetting('info:' .. p.key, value)
  log(xp, 'info', { key = p.key })
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
  return { ok = true }
end

H['admin:saveDefconLevels'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.defcon then return fail('Permission refusée.') end
  if type(p.levels) ~= 'table' then return fail('Format invalide.') end
  local out = {}
  for n in pairs(Config.Defcon) do
    local e = p.levels[tostring(n)] or p.levels[n]
    if type(e) == 'table' then
      out[tostring(n)] = {
        title = str(e.title, 60), message = str(e.message, 600),
        color = (type(e.color) == 'string' and e.color:match('^#%x%x%x%x%x%x$')) and e.color or nil,
      }
    end
  end
  saveSetting('defcon_levels', out)
  log(xp, 'defcon_levels')
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
  return { ok = true }
end

-- Suppression des historiques
H['admin:deleteApplication'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.recruitment then return fail('Permission refusée.') end
  local id = tonumber(p.id)
  if not id then return fail('Candidature introuvable.') end
  MySQL.update.await('DELETE FROM lspd_applications WHERE id=?', { id })
  log(xp, 'application_delete', { id = id })
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
  return { ok = true }
end

H['admin:purgeApplications'] = function(src, p)
  local perms, xp = getPerms(src)
  if not perms.recruitment then return fail('Permission refusée.') end
  local n
  if p.scope == 'all' then n = MySQL.update.await('DELETE FROM lspd_applications')
  elseif p.scope == 'done' then n = MySQL.update.await("DELETE FROM lspd_applications WHERE status IN ('accepted','refused')")
  else return fail('Portée invalide.') end
  log(xp, 'applications_purge', { scope = p.scope, count = n or 0 })
  TriggerClientEvent('core_lbapp:client:refresh', -1, 'lspd_app')
  return { ok = true, count = n or 0 }
end

H['admin:listLogs'] = function(src)
  if not getPerms(src).history then return fail('Permission refusée.') end
  return { ok = true, data = MySQL.query.await('SELECT id,name,action,details,created_at FROM lspd_logs ORDER BY id DESC LIMIT 200') }
end

H['admin:purgeLogs'] = function(src)
  local perms, xp = getPerms(src)
  if not perms.history then return fail('Permission refusée.') end
  MySQL.update.await('DELETE FROM lspd_logs')
  log(xp, 'logs_purge')
  return { ok = true }
end

-- ───────────── Dispatcher unique (une seule porte d'entrée réseau) ─────────────
ESX.RegisterServerCallback('lp:api', function(src, cb, action, payload)
  if type(action) ~= 'string' then return cb(fail('Requête invalide.')) end
  if not ready then return cb(fail('Initialisation en cours, réessayez dans un instant.')) end
  local h = H[action]
  if not h then return cb(fail('Action inconnue.')) end
  local now = GetGameTimer()
  if lastReq[src] and now - lastReq[src] < Config.RateLimitMs then return cb(fail('Trop de requêtes, réessayez.')) end
  lastReq[src] = now
  local ok, res = pcall(h, src, clean(type(payload) == 'table' and payload or {}) or {})
  if not ok then print('^1[lspd_app] erreur ' .. action .. ': ' .. tostring(res) .. '^0'); return cb(fail('Erreur interne.')) end
  cb(res)
end)

AddEventHandler('playerDropped', function() lastReq[source] = nil end)

-- ───────────── Démarrage : cache + valeurs par défaut (tables créées par server/sql.lua) ─────────────
local function init()
  local ok, err = pcall(function()
    for _, r in ipairs(MySQL.query.await('SELECT k,v FROM lspd_settings') or {}) do cache[r.k] = json.decode(r.v) end
    for k, v in pairs(Config.Defaults) do if cache[k] == nil then saveSetting(k, v) end end
    for key, kind in pairs(Config.InfoKeys) do
      if cache['info:' .. key] == nil then saveSetting('info:' .. key, kind == 'list' and {} or '') end
    end
    cache.defcon.updatedAt = cache.defcon.updatedAt or os.time()
  end)
  if ok then ready = true; print('^2[lspd_app] base de données prête^0')
  else print('^1[lspd_app] échec de l\'initialisation : ' .. tostring(err) .. '^0') end
end

AddEventHandler('lspd_app:dbReady', init)
if LSPD_SQL_READY then init() end

-- Météo : script client chargé par le core (l'enregistrement LB Phone / Tablet est fait par le core).
-- Météo : client. Lit en local la météo réellement appliquée au jeu (natives GTA) et l’affiche dans LB Phone / LB Tablet.
-- Aucun appel serveur : rien ne transite par le réseau.

local NAMES = { 'EXTRASUNNY', 'CLEAR', 'CLOUDS', 'SMOG', 'FOGGY', 'OVERCAST', 'RAIN', 'THUNDER', 'CLEARING',
  'NEUTRAL', 'SNOW', 'BLIZZARD', 'SNOWLIGHT', 'XMAS', 'HALLOWEEN' }
local TYPES = {}
for _, n in ipairs(NAMES) do TYPES[GetHashKey(n)] = n end

-- Renvoie : météo actuelle, météo de départ, météo d’arrivée, progression de la transition (0..1)
local function readWeather()
  local w1, w2, pct
  local ok, a, b, c = pcall(GetWeatherTypeTransition)
  if ok and a and b then w1, w2, pct = a, b, tonumber(c) or 0.0 end
  if not (w1 and TYPES[w1]) then w1 = GetPrevWeatherTypeHashName() end
  if not (w2 and TYPES[w2]) then w2 = GetNextWeatherTypeHashName(); pct = pct or 1.0 end
  local from, to = TYPES[w1], TYPES[w2]
  if not from and not to then return 'CLEAR', 'CLEAR', 'CLEAR', 1.0 end
  from, to = from or to, to or from
  pct = pct or 1.0
  if pct > 1.0 then pct = pct / 100.0 end
  if pct < 0.0 then pct = 0.0 end
  local current = pct >= 0.5 and to or from
  return current, from, to, pct
end

local function readLocation()
  local c = GetEntityCoords(PlayerPedId())
  local s1, s2 = GetStreetNameAtCoord(c.x, c.y, c.z)
  local street = (s1 and s1 ~= 0) and GetStreetNameFromHashKey(s1) or ''
  local cross  = (s2 and s2 ~= 0) and GetStreetNameFromHashKey(s2) or ''
  if cross == street then cross = '' end
  local code = GetNameOfZone(c.x, c.y, c.z)
  local zone = GetLabelText(code)
  if not zone or zone == '' or zone == 'NULL' then zone = code or '' end
  return { street = street, cross = cross, zone = zone }
end

local function getData()
  local hour, minute = GetClockHours(), GetClockMinutes()
  local weather, from, to, pct = readWeather()

  local override
  if Config.TemperatureProvider then
    local ok, v = pcall(Config.TemperatureProvider)
    if ok and tonumber(v) then override = tonumber(v) end
  end

  local forecast
  if Config.ForecastProvider then
    local ok, v = pcall(Config.ForecastProvider)
    if ok and type(v) == 'table' then forecast = v end
  end

  local dir = GetWindDirection()
  local deg = 0.0
  if dir then deg = (math.deg(math.atan(dir.x, dir.y)) + 360.0) % 360.0 end

  return {
    ok = true,
    place = Config.Place,
    loc = readLocation(),
    weather = weather, from = from, to = to, pct = pct,
    nextWeather = (from ~= to and pct > 0.02 and pct < 0.98 and weather ~= to) and to or nil,
    tempOverride = override,
    forecast = forecast,
    windSpeed = math.floor(GetWindSpeed() * 3.6 + 0.5),
    windDir = math.floor(deg + 0.5),
    rain = math.floor(GetRainLevel() * 100 + 0.5),
    snow = math.floor(GetSnowLevel() * 100 + 0.5),
    hour = hour, minute = minute,
    year = GetClockYear(), month = GetClockMonth(), day = GetClockDayOfMonth(), dow = GetClockDayOfWeek(),
    refresh = Config.RefreshMs,
  }
end

-- L’UI appelle fetchNui('meteo:get') : l’appel cible la ressource qui a enregistré l’app.
RegisterNUICallback('meteo:get', function(_, cb)
  local ok, data = pcall(getData)
  if not ok then
    if Config.Debug then print('[lb_meteo] erreur lecture météo : ' .. tostring(data)) end
    return cb({ ok = false, error = 'Lecture météo impossible.' })
  end
  cb(data)
end)

-- Réglages envoyés une seule fois à l’ouverture de l’app
RegisterNUICallback('meteo:config', function(_, cb)
  cb({ ok = true, place = Config.Place, refresh = Config.RefreshMs, temps = Config.Temperature, forecast = Config.Forecast })
end)

if Config.Debug then
  CreateThread(function()
    while true do
      Wait(5000)
      local d = getData()
      print(('[lb_meteo] %s (%s -> %s %.0f%%) | vent %s km/h | pluie %s%% | neige %s%% | %02d:%02d | %s / %s'):format(
        tostring(d.weather), tostring(d.from), tostring(d.to), d.pct * 100, d.windSpeed, d.rain, d.snow, d.hour, d.minute,
        d.loc.street, d.loc.zone))
    end
  end)
end

Config = {}

Config.Debug         = false            -- true : affiche l’état de l’enregistrement et les données météo dans la console F8
Config.AppIdentifier = 'lb-meteo'       -- identifiant unique de l’app (phone + tablet)
Config.AppName       = 'Météo'
Config.Place         = 'Los Santos'     -- affiché si la rue/le quartier ne peuvent pas être lus
Config.AppDescription = 'Météo en temps réel de Los Santos'

-- Compatibilité : mettre false pour désactiver un des deux supports
Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet

-- LB Tablet : false = chemin « html/index.html ». Si la page reste blanche sur la tablette, essayer true.
Config.TabletUiWithResourceName = false

-- Icône de l'app (dans html/)
Config.IconFile = 'icon.png'

-- false = l’app n’est PAS installée d’office (les joueurs la téléchargent depuis l’App Store du téléphone).
-- true  = installée directement chez tout le monde (conseillé pour remplacer l’app Météo native).
Config.DefaultApp    = true

-- Fréquence de mise à jour (ms). Tout est lu EN LOCAL sur le client : zéro appel serveur, zéro ping.
-- L’app se met en pause toute seule quand elle n’est pas affichée.
Config.RefreshMs = 2000

-- ─────────────────────────────────────────────────────────────
-- TEMPÉRATURES  { minimum de la nuit, maximum de l’après-midi }
-- La température suit une vraie courbe sur la journée (la plus froide vers 3h, la plus chaude vers 15h)
-- et glisse doucement d’une météo à l’autre pendant les transitions.
--
-- Pour une température FIXE (comme m-Weather), mets la même valeur deux fois : SNOW = { -4, -4 }
-- Garde ces valeurs identiques à celles de ton m-Weather.
-- ─────────────────────────────────────────────────────────────
Config.Temperature = {
  EXTRASUNNY = { 19, 30 }, CLEAR     = { 16, 26 }, CLOUDS    = { 14, 22 }, OVERCAST = { 12, 19 },
  RAIN       = { 10, 16 }, THUNDER   = { 11, 17 }, CLEARING  = { 12, 20 }, FOGGY    = { 8, 14 },
  SMOG       = { 15, 23 }, SNOWLIGHT = { -3, 1 },  SNOW      = { -7, -3 }, BLIZZARD = { -12, -6 },
  XMAS       = { -4, 0 },  NEUTRAL   = { 14, 22 }, HALLOWEEN = { 8, 14 },
}

-- Si tu connais un export / state bag de m-Weather qui donne la température exacte, renvoie-la ici (nombre en °C).
-- Retourner nil = utiliser le calcul ci-dessus.
-- Exemple : Config.TemperatureProvider = function() return exports['m-Weather']:NomDeLExport() end
Config.TemperatureProvider = nil

-- ─────────────────────────────────────────────────────────────
-- PRÉVISIONS (heures + jours suivants)
-- m-Weather ne permet pas de lire son planning : les prévisions sont donc une ESTIMATION, calculée de la même
-- façon chez tous les joueurs (tout le monde voit les mêmes prévisions). Le « maintenant » est, lui, 100 % réel.
--
-- pool : les météos possibles et leur poids (plus le chiffre est grand, plus c’est fréquent).
--        Mets ici les mêmes météos que dans le cycle de m-Weather.
-- stay : chance (0 à 1) que la météo reste la même d’un bloc au suivant.
-- blockHours : durée d’un bloc de météo, en heures du jeu.
-- maxJump : écart max (°C) entre deux météos qui se suivent. Évite un blizzard suivi d’une canicule dans les prévisions.
-- ─────────────────────────────────────────────────────────────
Config.Forecast = {
  days       = 7,
  blockHours = 4,
  stay       = 0.5,
  seed       = 1337,
  maxJump    = 12,
  pool = {
    CLEAR = 4, EXTRASUNNY = 2, CLOUDS = 3, OVERCAST = 2, RAIN = 2, THUNDER = 0.5, FOGGY = 1, CLEARING = 1,
    SNOWLIGHT = 1, SNOW = 1, BLIZZARD = 0.3,
  },
  -- Exemple serveur hivernal (remplace le pool ci-dessus par celui-ci) :
  -- pool = { OVERCAST = 3, CLOUDS = 2, SNOWLIGHT = 3, SNOW = 4, BLIZZARD = 1, FOGGY = 1, CLEAR = 1 },
}

-- Optionnel : fournis ton propre planning (ex. lu depuis m-Weather ou ta base).
-- Doit renvoyer une liste de jours : { { weather = 'SNOW', min = -6, max = -2, rain = 80 }, ... }  (rain = % de précipitations)
-- Retourner nil = utiliser l’estimation ci-dessus.
Config.ForecastProvider = nil

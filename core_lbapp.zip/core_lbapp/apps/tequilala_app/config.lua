Config = {}

-- Identifiant interne de l'application (ne pas changer après installation)
Config.AppIdentifier = 'tequilala'
Config.AppName       = 'Tequi-la-la'
Config.AppDescription = 'Carte, réservations, avis et recrutement du bar Tequi-la-la'

-- Compatibilité : mettre false pour désactiver un des deux supports
Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet

-- LB Tablet : false = chemin « html/index.html » (recommandé par la doc LB Tablet).
-- Si l'app reste blanche sur la tablette, essayer true.
Config.TabletUiWithResourceName = false

-- false = l'app n'est PAS imposée : le joueur l'installe depuis l'App Store du téléphone
-- et peut ensuite la SUPPRIMER comme n'importe quelle autre application.
-- true  = l'app est préinstallée chez tous les joueurs (et ne se désinstalle pas).
Config.DefaultApp = false

-- Lien de l'image de la carte (affichée dans l'onglet Carte, agrandissable)
Config.MenuImage = ''   -- ex. : 'https://.../carte.png'

-- Symbole de monnaie affiché dans l'interface
Config.Currency = '$'

-- Accès patron (vérifié côté serveur)
Config.Job            = 'tequilala'  -- nom du job ESX de Tequi-la-la
Config.MinGrade       = 5           -- grade minimum considéré comme « patron »
Config.BossGradeName  = 'boss'      -- ou nom du grade patron dans ta table job_grades

-- Propriétaires forcés (par identifier ESX), utile pour les tests
-- Exemple : ['license:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'] = true
Config.Owners = {}

-- Anti-spam (secondes entre deux envois du même joueur)
Config.Cooldown = {
    application = 30,
    request     = 30,
    review      = 15,
    appointment = 30
}

-- Rendez-vous : nombre maximum de RDV « en attente / confirmés » par joueur
Config.MaxActiveAppointments = 3

-- Menu : nombre maximum de liens (affiches / pages) que le patron peut publier
Config.MaxMenuLinks = 12

-- Si le joueur n'a pas de téléphone équipé, afficher une notification ESX classique
Config.EsxNotifyFallback = true

-- Valeurs par défaut créées uniquement si la base est vide
Config.DefaultSettings = {
    name        = 'Tequi-la-la',
    description = 'Tequi-la-la : tequilas, cocktails et ambiance festive. Réservez votre table et trinquez avec nous.',
    phone       = '',
    email       = '',
    hours       = 'Tous les jours : 18h - 4h'
}

Config.DefaultCategories = { 'Tequilas', 'Cocktails', 'Bières', 'Softs', 'Snacks', 'Bouteilles' }

-- Exemples de départ, tous modifiables ensuite dans Espace patron > Carte
-- { catégorie, nom, description, prix, conditions }
Config.DefaultServices = {
    { 'Tequilas',    'Tequila Blanco',      'Shot de tequila blanche, sel et citron vert.',          25,  '' },
    { 'Tequilas',    'Tequila Reposado',    'Vieillie en fût, douce et ambrée.',                      35,  '' },
    { 'Tequilas',    'Tequila Añejo',       'Longuement vieillie, à déguster lentement.',             55,  '' },
    { 'Cocktails',   'Margarita',           'Tequila, triple sec, citron vert, bord salé.',           40,  '' },
    { 'Cocktails',   'Tequila Sunrise',     'Tequila, jus d\'orange, grenadine.',                     38,  '' },
    { 'Cocktails',   'Paloma',              'Tequila, pamplemousse, citron vert, eau gazeuse.',       38,  '' },
    { 'Bières',      'Bière blonde',        'Pression fraîche 50 cl.',                                15,  '' },
    { 'Bières',      'Bière mexicaine',     'Bouteille bien fraîche avec rondelle de citron vert.',   18,  '' },
    { 'Softs',       'Soda / Jus de fruit', 'Au choix selon le stock.',                               8,   '' },
    { 'Snacks',      'Nachos & guacamole',  'À partager.',                                            25,  '' },
    { 'Bouteilles',  'Bouteille de tequila','Service en table avec mixers et glaçons.',               450, 'Réservation de table conseillée' }
}

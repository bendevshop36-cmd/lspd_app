Core = {}
Core.Apps = {
    { key = 'auto_exotic',   enabled = true, type = 'db',      callback = 'ae:api', developer = 'Auto Exotic' },
    { key = 'bahama_app',    enabled = true, type = 'db',      callback = 'bh:api', developer = 'Bahama' },
    { key = 'bennys_app',    enabled = true, type = 'db',      callback = 'bn:api', developer = 'Benny’s' },
    { key = 'burgershot_app',enabled = true, type = 'db',      callback = 'bs:api', developer = 'Burger Shot' },
    { key = 'tequilala_app', enabled = true, type = 'db',      callback = 'tq:api', developer = 'Tequi-la-la' },
    { key = 'lspd_app',      enabled = true, type = 'db',      callback = 'lp:api', developer = 'LSPD' },
    { key = 'bcso_app',      enabled = true, type = 'db',      callback = 'bc:api', developer = 'BCSO' },
    { key = 'lb_meteo',      enabled = true, type = 'client',  developer = 'Serveur' },
    { key = 'pdm_app',       enabled = true, type = 'catalog', developer = 'PDM' },
}

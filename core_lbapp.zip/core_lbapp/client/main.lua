local ESX = exports['es_extended']:getSharedObject()
local RESOURCE = GetCurrentResourceName()

local Apps = {} 

local function loadAppConfig(app)
    local path = ('apps/%s/config.lua'):format(app.key)
    local code = LoadResourceFile(RESOURCE, path)
    if not code then
        print(('^1[core_appli] %s introuvable^7'):format(path))
        return nil
    end
    local env = setmetatable({}, { __index = _G })
    local fn, err = load(code, '@' .. RESOURCE .. '/' .. path, 't', env)
    if not fn then
        print(('^1[core_appli] %s : %s^7'):format(path, tostring(err)))
        return nil
    end
    local ok, runErr = pcall(fn)
    if not ok or type(env.Config) ~= 'table' then
        print(('^1[core_appli] %s : config invalide %s^7'):format(path, tostring(runErr)))
        return nil
    end
    return env.Config
end

local function appDefinition(entry, system)
    local cfg, key = entry.cfg, entry.app.key
    -- LB Phone : chemin complet « ressource/dossier/fichier.html »
    -- LB Tablet : chemin relatif à la ressource qui enregistre l'app
    local base = ('apps/%s/html/index.html'):format(key)
    local ui = RESOURCE .. '/' .. base
    if system == 'lb-tablet' and not cfg.TabletUiWithResourceName then
        ui = base
    end
    return {
        identifier  = cfg.AppIdentifier,
        name        = cfg.AppName,
        description = cfg.AppDescription,
        developer   = entry.app.developer or cfg.AppName,
        defaultApp  = cfg.DefaultApp,
        size        = 6500,
        ui          = ui,
        icon        = ('https://cfx-nui-%s/apps/%s/html/%s'):format(RESOURCE, key, cfg.IconFile or 'logo.png'),
        fixBlur     = true
    }
end

local function register(entry, system)
    local ok, success, reason = pcall(function()
        return exports[system]:AddCustomApp(appDefinition(entry, system))
    end)
    if not ok then
        print(('^1[core_appli] %s : impossible d\'enregistrer l\'app dans %s : %s^7'):format(entry.app.key, system, tostring(success)))
    elseif success == false then
        print(('^3[core_appli] %s : %s a refusé l\'app : %s^7'):format(entry.app.key, system, tostring(reason)))
    end
end

local function registerAll()
    for _, entry in ipairs(Apps) do
        if entry.cfg.Phone  and GetResourceState('lb-phone')  == 'started' then register(entry, 'lb-phone')  end
        if entry.cfg.Tablet and GetResourceState('lb-tablet') == 'started' then register(entry, 'lb-tablet') end
    end
end

-- Chargement des configs + callbacks NUI (un par app : api_<dossier> / catalog_<clé>)
for _, app in ipairs(Core.Apps) do
    if app.enabled then
        local cfg = loadAppConfig(app)
        if cfg then
            local entry = { app = app, cfg = cfg }
            Apps[#Apps + 1] = entry

            if app.type == 'db' then
                -- Pont unique entre l'interface et le serveur. Droits toujours revérifiés côté serveur.
                RegisterNUICallback('api_' .. app.key, function(data, cb)
                    if type(data) ~= 'table' or type(data.action) ~= 'string' then
                        return cb({ ok = false, error = 'Requête invalide.' })
                    end
                    ESX.TriggerServerCallback(app.callback, function(result)
                        cb(result or { ok = false, error = 'Pas de réponse du serveur.' })
                    end, data.action, data.payload or {})
                end)
            elseif app.type == 'client' then
                -- App 100 % client : apps/<clé>/client.lua est exécuté ici avec sa propre Config
                local code = LoadResourceFile(RESOURCE, ('apps/%s/client.lua'):format(app.key))
                if not code then
                    print(('^1[core_appli] apps/%s/client.lua introuvable^7'):format(app.key))
                else
                    local env = setmetatable({ Config = cfg }, { __index = _G })
                    local fn, err = load(code, ('@%s/apps/%s/client.lua'):format(RESOURCE, app.key), 't', env)
                    if not fn then
                        print(('^1[core_appli] %s/client.lua : %s^7'):format(app.key, tostring(err)))
                    else
                        local ok, runErr = pcall(fn)
                        if not ok then print(('^1[core_appli] %s/client.lua : %s^7'):format(app.key, tostring(runErr))) end
                    end
                end
            elseif app.type == 'catalog' then
                -- Catalogue envoyé directement à l'interface (aucun serveur ni base)
                RegisterNUICallback('catalog_pdm', function(_, cb)
                    cb({
                        ok       = true,
                        shop     = cfg.Shop,
                        currency = cfg.Currency,
                        imageUrl = cfg.ImageUrl,
                        vehicles = cfg.Vehicles
                    })
                end)
            end
        end
    end
end

CreateThread(function()
    local waited = 0
    while waited < 60000 do
        local ready = true
        for _, entry in ipairs(Apps) do
            if (entry.cfg.Phone  and GetResourceState('lb-phone')  ~= 'started')
            or (entry.cfg.Tablet and GetResourceState('lb-tablet') ~= 'started') then
                ready = false
                break
            end
        end
        if ready then break end
        Wait(500)
        waited = waited + 500
    end
    registerAll()
end)

-- Rafraîchissement temps réel d'une app (envoyé par son serveur) : l'interface recharge ses données
RegisterNetEvent('core_lbapp:client:refresh', function(appKey)
    for _, entry in ipairs(Apps) do
        if entry.app.key == appKey then
            local id, evt = entry.cfg.AppIdentifier, entry.cfg.RefreshEvent or 'refresh'
            if entry.cfg.Phone and GetResourceState('lb-phone') == 'started' then
                pcall(function() exports['lb-phone']:SendCustomAppMessage(id, { event = evt }) end)
            end
            if entry.cfg.Tablet and GetResourceState('lb-tablet') == 'started' then
                pcall(function() exports['lb-tablet']:SendCustomAppMessage(id, evt, {}) end)
            end
            break
        end
    end
end)

AddEventHandler('onResourceStart', function(name)
    if name == 'lb-phone' or name == 'lb-tablet' then
        Wait(500)
        registerAll()
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= RESOURCE then return end
    for _, entry in ipairs(Apps) do
        local id = entry.cfg.AppIdentifier
        if GetResourceState('lb-phone') == 'started' then
            pcall(function() exports['lb-phone']:RemoveCustomApp(id) end)
        end
        if GetResourceState('lb-tablet') == 'started' then
            pcall(function() exports['lb-tablet']:RemoveCustomApp(id) end)
        end
    end
end)
